package com.std.StudentApp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.model.Course;
import com.model.Library;
import com.model.Student;
import com.model.Teacher;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Configuration configuration = new Configuration().configure("/resources/hibernate.cfg.xml");
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        
        Student std = new Student();
        std.setStdId(121);
        std.setName("Peter");
       
        Course course = new Course();
        course.setCourseId(101);
        course.setName("Java Programming");
        course.setDuration("6 months");
        course.setFee(8500);
        
        Library l1 = new Library();
        l1.setBookId(21);
        l1.setIssueDate("16/01/20");
        l1.setReturnDate("25/01/20");
        
        Library l2 = new Library();
        l2.setBookId(31);
        l2.setIssueDate("12/01/20");
        l2.setReturnDate("28/01/20");
        
        List<Library> books = new ArrayList<Library>();
        books.add(l1);
        books.add(l2);
        
        std.setBooks(books);
        std.setCourse(course);
		/*
		 * Teacher th = new Teacher(); th.setName("Allen"); th.setDept("Science");
		 */
        
        try {
        	
        	session.save(std);
			/* session.save(th); */
        	transaction.commit();
        	System.out.println("Record saved");
        }catch(Exception exception) {
        	transaction.rollback();
        	System.err.println("Problem : "+exception);
        }
    }
}

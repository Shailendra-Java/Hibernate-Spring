package com.model;

import java.util.List;

public class Student {

	private int stdId;
	private String name;
	private Course course;
	private List<Library> books;

	public List<Library> getBooks() {
		return books;
	}

	public void setBooks(List<Library> books) {
		this.books = books;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public int getStdId() {
		return stdId;
	}

	public void setStdId(int stdId) {
		this.stdId = stdId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
